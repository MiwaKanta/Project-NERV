const imgs =["./img/building3.jpg","./img/library2.jpg","./img/hall.jpg"];

let i = 0;
function slide() {
    i++;
    if ( i > 2) {
        i = 0;
    }
    document.getElementById("img").src = imgs[i];
}

setInterval(slide, 1000)